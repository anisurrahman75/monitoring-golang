package main

import (
	"fmt"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"log"
	"math/rand"
	"net/http"
	"strconv"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

type statusRecorder struct {
	http.ResponseWriter
	statusCode int
}

var httpRequestCounter = prometheus.NewCounterVec(prometheus.CounterOpts{
	Name: "http_requests_total",
	Help: "Total number of HTTP requests received",
}, []string{"status", "path", "method"})

var activeRequestsGauge = prometheus.NewGauge(
	prometheus.GaugeOpts{
		Name: "http_active_requests",
		Help: "Number of active connections to the service",
	},
)

var dbQueryHistogram = prometheus.NewHistogramVec(
	prometheus.HistogramOpts{
		Name: "db_query_duration_seconds",
		Help: "Histogram of database query latencies in seconds.",
		//Buckets: prometheus.DefBuckets,              // Default: 5ms to 10s
		Buckets: []float64{0.1, 0.5, 1, 2.5, 5, 10}, // You also can declare custom bucket time

	},
	[]string{"query_type"},
)

func httpRequestCount(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder := &statusRecorder{
			ResponseWriter: w,
			statusCode:     http.StatusOK,
		}
		method := r.Method
		path := r.URL.Path
		status := strconv.Itoa(recorder.statusCode)
		next.ServeHTTP(recorder, r)
		httpRequestCounter.WithLabelValues(status, path, method).Inc()
	})
}

func activeRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		activeRequestsGauge.Inc()
		defer activeRequestsGauge.Dec()
		// Simulate processing time
		delay := time.Duration(rand.Intn(900)) * time.Millisecond
		time.Sleep(delay)
		next.ServeHTTP(w, r)
	})

}

func dbQuery(w http.ResponseWriter, r *http.Request) {
	executeDBQuery := func(queryType string) {
		start := time.Now()
		delay := time.Duration(rand.Intn(900)) * time.Millisecond
		time.Sleep(delay)
		dbQueryHistogram.WithLabelValues(queryType).Observe(time.Since(start).Seconds())
	}

	queryTypes := []string{"SELECT"} //  "INSERT", "UPDATE", "DELETE"
	randomQuery := queryTypes[rand.Intn(len(queryTypes))]
	executeDBQuery(randomQuery)
	w.Write([]byte(fmt.Sprintf("Executed %s query\n", randomQuery)))
}

var httpRequestSummary = prometheus.NewSummaryVec(
	prometheus.SummaryOpts{
		Name:       "http_request_duration_summary_seconds",
		Help:       "Summary of HTTP request durations in seconds.",
		Objectives: map[float64]float64{0.5: 0.05, 0.9: 0.01, 0.99: 0.001},
	},
	[]string{"method", "path"},
)

func summary(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		duration := time.Since(start).Seconds()
		httpRequestSummary.WithLabelValues(r.Method, r.URL.Path).Observe(duration)
	})
}

func MyHandler(w http.ResponseWriter, _ *http.Request) {
	w.Write([]byte("Hello world!"))
}

func init() {
	// Register the metrics with Prometheus
	newReg.MustRegister(httpRequestCounter, activeRequestsGauge, dbQueryHistogram, httpRequestSummary)
}

var newReg = prometheus.NewRegistry()

func main() {
	r := chi.NewRouter()
	r.Use(middleware.Logger)
	r.Use(httpRequestCount)
	r.Use(activeRequests)
	r.Use(summary)

	r.HandleFunc("/", MyHandler)
	r.HandleFunc("/db-query", dbQuery)
	r.Handle("/metrics", promhttp.HandlerFor(newReg, promhttp.HandlerOpts{}))

	log.Println("Starting main HTTP server on http://localhost:8000")
	log.Fatal(http.ListenAndServe("localhost:8000", r))
}
